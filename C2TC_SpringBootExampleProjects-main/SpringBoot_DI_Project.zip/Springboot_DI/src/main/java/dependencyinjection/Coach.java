package dependencyinjection;

public interface Coach {
	   String getTraining();
}
