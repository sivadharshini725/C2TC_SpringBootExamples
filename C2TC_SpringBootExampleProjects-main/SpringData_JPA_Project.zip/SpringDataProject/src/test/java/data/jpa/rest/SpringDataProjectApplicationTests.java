package data.jpa.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
